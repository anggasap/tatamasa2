<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$active_group = 'config1';
$active_record = TRUE;

$db['config1']['hostname'] = 'localhost';
$db['config1']['username'] = 'root';
$db['config1']['password'] = '';
$db['config1']['database'] = 'tatamasa';
$db['config1']['dbdriver'] = 'mysql';
$db['config1']['dbprefix'] = '';
$db['config1']['pconnect'] = TRUE;
$db['config1']['db_debug'] = TRUE;
$db['config1']['cache_on'] = FALSE;
$db['config1']['cachedir'] = '';
$db['config1']['char_set'] = 'utf8';
$db['config1']['dbcollat'] = 'utf8_general_ci';
$db['config1']['swap_pre'] = '';
$db['config1']['autoinit'] = TRUE;
$db['config1']['stricton'] = FALSE; 